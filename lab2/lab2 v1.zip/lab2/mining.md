In the following, I will demostrate how to join a private Ethereum network and start mining to gain ether.

After the preparation, there are four nodes (1 bootnode, 3 nodes) in your computer.

1. We fist launch the blockchain network by running the bootnode, and compute its enode url.
   The format of enode url is **node_ID@ip_addr:port**
   ```sh
   docker attach boot
   ip addr
   ./start_console.sh
   admin.nodeInfo
   ```
   After `docker attach boot`, we enter into the running bootnode container.
   
   After `ip addr`, we can get the ip addr of bootnode, e.g., **172.17.0.2**.
   
   After `./start_console.sh`, we launch the geth client in bootnode.
   
   After `admin.nodeInfo`, we get the node id and port of the bootnode, e.g., **d04a809e4dbf5758c8f4ee8abacc12bbc5abc71daafe9b3bf869a688ef64aaf02d88a907cb5c07683fcf2b82b68afe4c0755c6ad5b2b1a7a522ffaa8d0b7de98** and **30303**.

   Hence, the enode url of the bootnode is **enode://d04a809e4dbf5758c8f4ee8abacc12bbc5abc71daafe9b3bf869a688ef64aaf02d88a907cb5c07683fcf2b82b68afe4c0755c6ad5b2b1a7a522ffaa8d0b7de98@172.17.0.2:30303**
   
   Finally, you can exit the bootnode with keeping it alive.

2. We then launch 3 nodes and connect them to the bootnode.
   ```sh
   docker attach node1
   ./start_console.sh enode://d04a809e4dbf5758c8f4ee8abacc12bbc5abc71daafe9b3bf869a688ef64aaf02d88a907cb5c07683fcf2b82b68afe4c0755c6ad5b2b1a7a522ffaa8d0b7de98@172.17.0.2:30303
   ```
   After `docker attach node1`, we enter into the running node1 container.
   
   After `./start_console.sh enode://d04a809e4dbf5758c8f4ee8abacc12bbc5abc71daafe9b3bf869a688ef64aaf02d88a907cb5c07683fcf2b82b68afe4c0755c6ad5b2b1a7a522ffaa8d0b7de98@172.17.0.2:30303`, we launch the geth 
   client in node1 and connect it to the bootnode.

   You can exit node1 while keeping it alive.

   Then, repeat the same steps to launch the geth clients in node2 and node3.

3. Then we create accounts for each node.
   ```sh
   docker attach node1
   personal.newAccount('1234')
   ```
   You should see an account address like this "0x4f46f70cd008677a704fff2d09f69a21298a89fb".

   Repeat the same step for node2 and node3.

4. Set etherbase for each node and start mining. For example, in node1:
   ```sh
   docker attach node1
   miner.setEtherbase("0x4f46f70cd008677a704fff2d09f69a21298a89fb")
   miner.start()
   ```

   After starting mining, you can repeatively check the balance of this account and you will notice that the balance is increasing.
   ```sh
   eth.getBalance("0x4f46f70cd008677a704fff2d09f69a21298a89fb")
   ```

   You can repeat this step for node2 and node3.