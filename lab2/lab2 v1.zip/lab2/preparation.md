You need to install "docker" into your computer first if it is not installed.

## Step 1: build docker images
1. enter into the `bootnode` path, e.g., `cd ./bootnode/`
2. run `docker build -t bootnode .` to build the `bootnode` image
3. enter into the `node` path, e.g., `cd ./node/`
4. run `docker build -t node .` to build the `node` image
5. run `docker image ls` to check the images, the terminal will output contents like the following information

   ```sh
   REPOSITORY   TAG       IMAGE ID       CREATED              SIZE
   node         latest    8b5f11362527   2 minutes ago        384MB
   bootnode     latest    fc73c32f49bd   3 minutes ago        384MB
   ```

## step 2: start containers
We will start four containers in lab1. One for bootnode first launches the blockchain network and three for miner nodes.
1. launch the bootnode by `docker run --name boot -it bootnode /bin/bash`, and tap `Ctrl + P + Q` to exit the container with keeping it alive
2. launch three nodes and do not forget to exit them with keeping them alive
   ```sh
   docker run --name node1 -it node /bin/bash
   docker run --name node2 -it node /bin/bash
   docker run --name node3 -it node /bin/bash
   ```
3. check the running containers by `sudo docker ps`, and the terminal will output contents like the following information
   ```sh
   CONTAINER ID   IMAGE      COMMAND                  CREATED          STATUS          PORTS                            NAMES
   8946118bc9e9   node       "/bin/sh -c sh /bin/…"   7 minutes ago    Up 7 minutes    8545/tcp, 30303/tcp, 30303/udp   node3
   6d6de5f0b93d   node       "/bin/sh -c sh /bin/…"   8 minutes ago    Up 8 minutes    8545/tcp, 30303/tcp, 30303/udp   node2
   99c0f536eda2   node       "/bin/sh -c sh /bin/…"   9 minutes ago    Up 9 minutes    8545/tcp, 30303/tcp, 30303/udp   node1
   de62c6d9b6fa   bootnode   "/bin/sh -c sh /bin/…"   11 minutes ago   Up 11 minutes   8545/tcp, 30303/tcp, 30303/udp   boot
   ```
