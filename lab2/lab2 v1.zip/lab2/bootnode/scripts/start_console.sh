geth --datadir /geth_node/datadir --rpc --rpccorsdomain "*" console 2> /geth_node/log
